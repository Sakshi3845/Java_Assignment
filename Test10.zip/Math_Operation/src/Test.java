import java.util.Scanner;

class Add{
	int a,b,c;

	public void Add() {
	int a=10;
	int b=5;
	int c=a+b;
	System.out.println(c);
     }
	
	public void Sub() {
		int a=5;
		int b=2;
		int c=a-b;
		System.out.println(c);
}
	
	public void Add(int d,int e) {
		a=d;
		b=e;
		c=a+b;
		System.out.println(c);
		
	}
	public void Mul(){
		 a=20;
		 b=30;
		c=a*b;
		System.out.println(c);
	}
	
	public void Div() {
		int a;
		int b;
		int c;
		
		Scanner sc= new Scanner(System.in);
		try {
			 System.out.print("Enter the value of a: ");
	            a = sc.nextInt();

	            System.out.print("Enter the value of b: ");
	            b = sc.nextInt();
			c =a/b;
			  System.out.println("Result of division: " + c);
        } catch (ArithmeticException e) {
            System.out.println("Error : Division by zero is not allowed.");
        } finally {
            sc.close();
		}
		
	}
	


}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Add a1=new Add();
		Add a2=new Add();
		a1.Add();
		a2.Sub();
		a1.Add(10,20);
		a1.Mul();
		a1.Div();
		
		
		
		

	}

}
