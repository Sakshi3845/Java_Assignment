
public class Test2 {
	
	//area of rect
	public void Area(int l,int b) {
		int l1,b1;
		 l1=l;
		 b1=b;
		System.out.println("area of rectangle : "+l*b);
		
	}
	//area of circle
	public void Area(float pi,int r) {
		float pi1;
		int r1;
		 pi1=pi ;
		 r1=r;
		System.out.println("area of Circle : "+pi*r*r);
		
	}
	//public void Area()

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Test2 a1=new Test2();
     Test2 a2=new Test2();

     a1.Area(10,5);
     a2.Area(3.14f,2);
    
     
	}

}
