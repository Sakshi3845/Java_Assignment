import java.util.Scanner;

public class Test4 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
				
		System.out.print("Enter the First no: ");
        int a = sc.nextInt();

        System.out.print("Enter the Second no: ");
        int b = sc.nextInt();
        
        System.out.print("Enter your choice: ");
        int choice = sc.nextInt();
        
        int c=0;
        
        switch (choice) {
        case 1:
            c = a + b;
            System.out.println("Addition result: " + c);
            break;
            
            case 2:
                c = a - b;
                System.out.println("Subtraction result: " + c);
                break;
                
            case 3:
                c = a * b;
                System.out.println("Multiplication result: " + c);
                break;
                
            case 4:          
                try {
                    c = a / b;
                    System.out.println("Division result: " + c);
                } catch (ArithmeticException e) {
                    System.out.println("Error: Division by zero is not allowed.");
                }
                
            default:
                System.out.println("Invalid !!!");
                break;
                

	}
        sc.close();

}
}
