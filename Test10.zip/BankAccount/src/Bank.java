class Bank {
    int accNo;
    String HolderName;
    double balance;

    public Bank(int accNo, String HolderName, double balance) {
        this.accNo = accNo;
        this.HolderName = HolderName;
        this.balance = balance;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: " + amount);
        } else {
            System.out.println("Deposit amount must be positive.");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            System.out.println("Withdrew: " + amount);
        } else if (amount > 0 && balance < amount) {
            System.out.println("Insufficient balance. Withdrawal failed.");
        } else {
            System.out.println("Withdrawal amount must be positive.");
        }
    }

    public void displayAccountInfo() {
        System.out.println("Account Number: " + accNo);
        System.out.println("Account Holder: " + HolderName);
        System.out.println("Balance: $" + balance);
    }

    public static void main(String[] args) {
        Bank account = new Bank(123456, "Sakshi Wagh", 2000.00);

        account.displayAccountInfo();

        account.deposit(200);

        account.withdraw(500);

        account.withdraw(800);

        account.displayAccountInfo();
    }
}
