import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the Nos :");
		int n=sc.nextInt();
		
		if(n<=1) {
			System.out.println(n+"Number is not prime");
		}
		
		else {
			int i=2;
            while (i <= n / 2) {
                if (n % i == 0) {
                    System.out.println(n + " is not a prime number.");
                    return;
                }
                i++;
            }
            System.out.println(n + " is a prime number.");
        }

        sc.close();
		}
		

	}


