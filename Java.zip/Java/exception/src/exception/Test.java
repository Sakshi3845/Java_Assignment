package exception;

class Account{
	protected double balance;

	public Account(double balance) {
		super();
		this.balance=balance;
	}
	
	public void deposit(double amount) {
		balance=balance+amount;
	}
	
	public void withdraw(double amount)throws Exception{
		if(amount>balance) {
			throw new Exception("Insufficient balance...");
		}
		else if(amount>15000) {
			throw new Exception("overlimit...");
			
		}
		else {
			balance=balance-amount;
		}
	}
	
	
}
public class Test {

	public static void main(String[] args) {
		Account a=new Account(30000);
		try {
			a.withdraw(1000);
			System.out.println(a.balance);
		}
		catch (Exception e){
			System.out.println(e);
			
		}
		// TODO Auto-generated method stub

	}

}
