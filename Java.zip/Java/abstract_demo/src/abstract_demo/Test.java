package abstract_demo;

abstract class animal{
	abstract void sound(); 
}
	
	class dog extends animal{
		void sound() {
		System.out.println("bark...");


		
	}
}

public class Test {

	public static void main(String[] args) {
		
		dog d=new dog();
		d.sound();
		// TODO Auto-generated method stub

	}

}
