
import java.util.Scanner;

class Student {
    private int rollno;
    private String name;
    private float percentage;
    
    private static int cnt = 0;
    
    public Student(int rollno, String name, float percentage) {
        this.rollno = rollno;
        this.name = name;
        this.percentage = percentage;
        cnt++;
    }
    
    public int getRollno() {
        return rollno;
    }

    public void setRollno(int rollno) {
        this.rollno = rollno;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getPercentage() {
        return percentage;
    }

    public void setPercentage(float percentage) {
        this.percentage = percentage;
    }

    public static int getCount() {
        return cnt;
    }

    @Override
    public String toString() {
        return "Roll No: " + rollno + ", Name: " + name + ", Percentage: " + percentage;
    }
}

public class Test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter the number of students: ");
        int numStudents = sc.nextInt();
        sc.nextLine();        
        Student[] students = new Student[numStudents];
        
        for (int i = 0; i < numStudents; i++) {
            System.out.print("Enter roll number for student " + (i + 1) + ": ");
            int rollno = sc.nextInt();
            sc.nextLine(); 
            System.out.print("Enter name for student " + (i + 1) + ": ");
            String name = sc.nextLine();
            System.out.print("Enter percentage for student " + (i + 1) + ": ");
            float percentage = sc.nextFloat();
            sc.nextLine(); 
            
            students[i] = new Student(rollno, name, percentage);
        }
        
        System.out.println("\nStudent Details:");
        for (Student student : students) {
            System.out.println(student);
        }
        
        System.out.println("\nTotal number of Student objects created: " + Student.getCount());
        
        sc.close();
    }
}
