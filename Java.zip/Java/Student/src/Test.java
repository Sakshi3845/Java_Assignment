import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Student {
    private int rollNo;
    private String name;
    private String studentClass;
    private double percentage;

    public Student(int rollNo, String name, String studentClass, double percentage) {
        this.rollNo = rollNo;
        this.name = name;
        this.studentClass = studentClass;
        this.percentage = percentage;
    }

    public int getRollNo() {
        return rollNo;
    }

    public String getName() {
        return name;
    }

    public String getStudentClass() {
        return studentClass;
    }

    public double getPercentage() {
        return percentage;
    }

    public void setRollNo(int rollNo) {
        this.rollNo = rollNo;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStudentClass(String studentClass) {
        this.studentClass = studentClass;
    }

    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }

    @Override
    public String toString() {
        return "Roll No: " + rollNo + ", Name: " + name + ", Class: " + studentClass + ", Percentage: " + percentage;
    }

    public void displayStudent() {
        System.out.println(this.toString());
    }
}

class UtilityList {
    private List<Student> list;

    public UtilityList() {
        list = new ArrayList<>();
    }

    public void createList() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of students: ");
        int numberOfStudents = sc.nextInt();

        for (int i = 0; i < numberOfStudents; i++) {
            System.out.println("Enter details for student " + (i + 1) + ":");
            System.out.print("Roll No: ");
            int rollNo = sc.nextInt();
            sc.nextLine(); 
            System.out.print("Name: ");
            String name = sc.nextLine();
            System.out.print("Class: ");
            String studentClass = sc.nextLine();
            System.out.print("Percentage: ");
            double percentage = sc.nextDouble();

            Student student = new Student(rollNo, name, studentClass, percentage);
            list.add(student);
        }
    }

    public void printList() {
        for (Student student : list) {
            student.displayStudent();
        }
    }
}

public class Test {
    public static void main(String[] args) {
        UtilityList utilityList = new UtilityList();
        utilityList.createList(); 
        utilityList.printList();  
    }
}
