
public class Employee {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the EmpId:");
		int EmpId=sc.nextInt();

		System.out.println("Enter the 1st no:");
		int a=sc.nextInt();
		String a=sc.nextInt();
		// TODO Auto-generated method stub

	}

}
