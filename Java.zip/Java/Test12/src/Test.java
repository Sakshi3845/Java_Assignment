import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the 1st no:");
		int a=sc.nextInt();
		
		System.out.println("Enter the 2nd no: ");
		int b=sc.nextInt();
		
		a=a+b;
		b=a-b;
		a=a-b;
		
		System.out.println("After swapping:");
		System.out.println("first Number : "+a);
		System.out.println("Second Number : "+b);


	


sc.close();
}
}


