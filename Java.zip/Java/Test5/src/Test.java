import java.util.Scanner;

public class Test {

    public static int factIt(int n) {
        int n1 = 1;
        for (int i = 1; i <= n1; i++) {
            n1 *= i;
        }
        return n1;
    }

    public static int factRe(int n1) {
        if (n1 == 0 || n1 == 1) {
            return 1;
        } else {
            return n1 * factRe(n1 - 1);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int num = sc.nextInt();

        int iterFact = factIt(num);
        System.out.println("Factorial1: " + iterFact);

        int recFact = factRe(num);
        System.out.println("Factorial2: " + recFact);

        sc.close();
    }
}
