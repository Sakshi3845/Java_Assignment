import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Student {
    int rlno;
    String name;
    String classs;
    double percentage;

    Student(int rlno, String name, String classs, double percentage) {
        this.rlno = rlno;
        this.name = name;
        this.classs = classs;
        this.percentage = percentage;
    }

    @Override
    public String toString() {
        return "Student [Roll No: " + rlno + ", Name: " + name + ", Class: " + classs + ", Percentage: " + percentage + "]";
    }
}

class UtilityList {
    private List<Student> studentList = new ArrayList<>();

    public void createList() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the Student Roll No: ");
        int rlno = sc.nextInt();
        sc.nextLine(); 

        System.out.println("Enter the Student Name: ");
        String name = sc.nextLine();

        System.out.println("Enter the Student Class: ");
        String classs = sc.nextLine();

        System.out.println("Enter the Student Percentage: ");
        double percentage = sc.nextDouble();

        Student student = new Student(rlno, name, classs, percentage);
        studentList.add(student);
    }

    public void printList() {
        if (studentList.isEmpty()) {
            System.out.println("No students in the list.");
        } else {
            for (Student student : studentList) {
                System.out.println(student);
            }
        }
    }
}

public class Test1 {
    public static void main(String[] args) {
        UtilityList utilityList = new UtilityList();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Add Student");
            System.out.println("2. Print Student List");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    utilityList.createList(); 
                    break;
                case 2:
                    utilityList.printList(); 
                    break;
                case 3:
                    System.out.println("Exiting...");
                    sc.close();
                    return; 
                default:
                    System.out.println("Invalid choice. Please try again.!!!");
            }
        }
    }
}
