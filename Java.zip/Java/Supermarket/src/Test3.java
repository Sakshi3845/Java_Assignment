import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Customer {
    private static int cnt = 1;
    int cid;
    String cname;
    List<Product> cart = new ArrayList<>();
    double bills;

    public Customer() {
        this.cid = cnt++;
        this.cname = "Customer" + cid;

    public void addToCart(Product product) {
        cart.add(product);
        bills += product.price; 
    }

    public void showCart() {
        System.out.println("Customer ID: " + cid);
        System.out.println("Customer Name: " + cname);
        System.out.println("Cart Items:");
        for (Product product : cart) {
            System.out.println(product);
        }
        System.out.println("Total Bill: " + bills);
    }
}

class Product {
    int pid;
    String pname;
    double price;

    public Product(int pid, String pname, double price) {
        this.pid = pid;
        this.pname = pname;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product [ID: " + pid + ", Name: " + pname + ", Price: " + price + "]";
    }
}


public class Test3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        List<Customer> customers = new ArrayList<>();
        
        List<Product> products = new ArrayList<>();
        products.add(new Product(1, "Product1", 100.0));
        products.add(new Product(2, "Product2", 200.0));
        products.add(new Product(3, "Product3", 300.0));

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Add Customer");
            System.out.println("2. Add Product to Customer Cart");
            System.out.println("3. Show Customer Cart");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    Customer customer = new Customer();
                    customers.add(customer);
                    System.out.println("Customer " + customer.cname + " added.");
                    break;

                case 2:
                    System.out.print("Enter Customer ID: ");
                    int cid = sc.nextInt();
                    Customer selectedCustomer = null;
                    for (Customer c : customers) {
                        if (c.cid == cid) {
                            selectedCustomer = c;
                            break;
                        }
                    }
                    if (selectedCustomer != null) {
                        System.out.println("Available Products:");
                        for (Product product : products) {
                            System.out.println(product);
                        }
                        System.out.print("Enter Product ID to add to cart: ");
                        int pid = sc.nextInt();
                        Product selectedProduct = null;
                        for (Product product : products) {
                            if (product.pid == pid) {
                                selectedProduct = product;
                                break;
                            }
                        }
                        if (selectedProduct != null) {
                            selectedCustomer.addToCart(selectedProduct);
                            System.out.println("Product added to " + selectedCustomer.cname + "'s cart.");
                        } else {
                            System.out.println("Product not found.");
                        }
                    } else {
                        System.out.println("Customer not found.");
                    }
                    break;

                case 3:
                    System.out.print("Enter Customer ID: ");
                    cid = sc.nextInt();
                    selectedCustomer = null;
                    for (Customer c : customers) {
                        if (c.cid == cid) {
                            selectedCustomer = c;
                            break;
                        }
                    }
                    if (selectedCustomer != null) {
                        selectedCustomer.showCart();
                    } else {
                        System.out.println("Customer not found.");
                    }
                    break;

                case 4:
                    System.out.println("Exiting...");
                    sc.close();
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
