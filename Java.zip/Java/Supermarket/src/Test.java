import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class Customer{
	
	private int cid;
	private String cname;
	private int[][] cart=new int[10][20];
	private double bills;
	
	
	public Customer(int cid, String cname, int[][] cart, double bills) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.cart = cart;
		this.bills = bills;
	}
	public void display() {
        System.out.println("Customer ID: " + cid);
        System.out.println("Customer Name: " + cname);
        System.out.println("Cart: " + cart);
        System.out.println("Bills:"+ bills);
    }
	
	@Override
	public String toString() {
		return "Customer [cid=" + cid + ", cname=" + cname + ", cart=" + Arrays.toString(cart) + ", bills=" + bills
				+ "]";
	}

	class Product {
		private int pid;
		private String pnmae;
		private double price;
		public Product(int pid, String pnmae, double price) {
			this.pid = pid;
			this.pnmae = pnmae;
			this.price = price;
		}
		public Product(int cid, String cname, int[][] cart, double bills, int pid, String pnmae, double price) {
			super(cid, cname, cart, bills);
			this.pid = pid;
			this.pnmae = pnmae;
			this.price = price;
		}
		@Override
		public String toString() {
			return "Product [pid=" + pid + ", pnmae=" + pnmae + ", price=" + price + "]";
		}
		
		
	}
	
	class Admin{
		
		
		
	}
	
	
}
public class Test {

	public static void main(String[] args) {
		List<String> Customers=new ArrayList<>();


	}

}
