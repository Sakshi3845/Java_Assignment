package list_interface;

import java.util.Vector;

public class Test1 {

	public static void main(String[] args) {
		
		Vector <Integer> v1=new Vector<>();
		v1.add(1);
		v1.add(2);
		v1.add(10);
		v1.add(0);
		v1.clone();
		System.out.println(v1);
		
		for(int name:v1) {
			System.out.println(name);
		}
		

	}

}
