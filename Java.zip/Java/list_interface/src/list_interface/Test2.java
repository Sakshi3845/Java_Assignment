package list_interface;

import java.util.LinkedList;
import java.util.List;

public class Test2 {

	public static void main(String[] args) {
		
		List<String> linkls=new LinkedList<>();
		linkls.add("apple");
		linkls.add("banana");
		linkls.add("cherry");
		linkls.add("cherry");
		System.out.println(linkls);
	//	linkls.remove(0);
		for(String name :linkls) {
			System.out.println(name);
		}

	}

}
