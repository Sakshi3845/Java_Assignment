import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	
System.out.println("Enter the String:");
String str=sc.next();

String strev = "";

for (int i = str.length() - 1; i >= 0; i--) {
    strev += str.charAt(i);
}

if (str.equals(strev)) {
    System.out.println(str + " is a palindrome.");
} else {
    System.out.println(str + " is not a palindrome.");
}

sc.close();

	}

}
