import java.util.HashMap;
import java.util.LinkedHashMap;//it preserve the order
import java.util.*;

public class Test {

	public static void main(String[] args) {
		Map<Integer, String>hashmap=new HashMap();
		hashmap.put(1,"Sakshi");
		hashmap.put(2,"Om");
		hashmap.put(3,"shree");
		hashmap.put(null, "sam");//allows null key
		hashmap.put(7,"Om");

		hashmap.remove(3);
		hashmap.equals(2);
		System.out.println(hashmap.size());
		System.out.println(hashmap);
		
		Map<Integer,String>treemap=new TreeMap();
		treemap.put(4, "Mohan");
		treemap.put(5, "radha");
		treemap.put(6,"tara");
		System.out.println("Treemap sorted order :"+treemap);
		System.out.println(treemap.get(5));
		System.out.println();
		
		
	}

}
