import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Employee{
		int empid;
		String empname;
		double salary;
		
		public Employee() {
			empid=101;
			empname="Sakshi";
			salary=20000;
			
		}

		public Employee(int empid, String empname, double salary) {
			super();
			this.empid = empid;
			this.empname = empname;
			this.salary = salary;
		}
		
		public void Accept() {
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter Employee id :");
			empid=sc.nextInt();
			
			System.out.println("Enter empname:");
			empname=sc.next();
			
			System.out.println("Enter the salary");
			salary=sc.nextDouble();
			
			
		}

		@Override
		public String toString() {
			return "Employee [empid=" + empid + ", empname=" + empname + ", salary=" + salary + "]";
		}
		
	}
public class Test {
	
	

	public static void main(String[] args) {
		List<Employee> e=new ArrayList<Employee>();
		Scanner sc=new Scanner(System.in);
		while(true) {
			int choice;
			System.out.println("1.Add employee details : ");
			System.out.println("2.Display Employee details : ");
			System.out.println("3.Update Employee Details : ");
			System.out.println("4.Exit");
			System.out.println("Enter your choice : ");
			choice=sc.nextInt();
			
			switch(choice) {
			case 1:
				Employee e1=new Employee();
				e1.Accept();
				e.add(e1);
				break;
				
				
			case 2:
				System.out.println("Details of Employees :");
				for(int i=0;i<e.size();i++) {
					System.out.println(e.get(i).empid+" "+e.get(i).empname+" "+e.get(i).salary+" ");
				}
				System.out.println();
				break;
		
		
		case 3:
			System.out.println("Enter emp id:");
			int uempid=sc.nextInt();
			double sal = 0;
			boolean found=false;
			for(int i=0;i<=e.size();i++) {
				if(uempid==e.get(i).empid) {
					System.out.println("Enter updated salary : "+sal);
					sal=sc.nextDouble();
					e.get(i).salary=sal;
					found=true;
					System.out.println("Salary updated!!!");
					break;
				}
			}
				if(!found) {
					System.out.println("Employee with id"+uempid+"not found");
				}
				break;
				
			case 4:
					System.exit(0);	
			
			break;

	}
	}
	}
}
