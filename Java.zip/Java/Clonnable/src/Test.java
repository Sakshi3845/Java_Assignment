class vehicle{
	private int vno;
	private String vname;
	private double cost;
	
	
	public vehicle() {
		super();
		vno=0;
		vname="";
		cost=0;
	}
	
	public vehicle(int vno, String vname, double cost) {
		super();
		this.vno = vno;
		this.vname = vname;
		this.cost = cost;
	}
	
	public void show() {
		System.out.println(vno+" "+vname+" "+cost+" ");
	}
	
	@Override
	public String toString() {
		return "vehicle [vno=" + vno + ", vname=" + vname + ", cost=" + cost + "]";
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	
}
public class Test {

	public static void main(String[] args) {
		
		vehicle v=new vehicle(101,"bmw",20000);
		v.show();
		try {
		
		vehicle v1=(vehicle)v.clone();
		v1.show();
		}
		catch (Exception e) {
			
			System.out.println(e);
		}
		// TODO Auto-generated method stub

	}

}
