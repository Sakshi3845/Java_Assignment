package list_interface;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Test {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list1=new ArrayList<>();
		list1.add("apple");
		list1.add("Banana");
	list1.add("orange");
	list1.get(2);
		list1.add(1, "guava");
		list1.remove(0);
		list1.add("cherry");
		list1.remove("apple");
		boolean isp=list1.contains("orange");
//		System.out.println(isp);
//		System.out.println(list1.size());
		System.out.println(list1);
//		System.out.println(list1.isEmpty());
		
		Iterator<String> arritr=list1.iterator();
		while(arritr.hasNext())
		{
			String l=arritr.next();
			System.out.println(l);
		}
//		
		
	//list1.clear();

	}

}
