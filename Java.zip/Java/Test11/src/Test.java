import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the 1st no :");
		int a=sc.nextInt();
		
		System.out.println("Enter the 2nd no :");
		int b=sc.nextInt();
		
		System.out.println("Enter the 3rd no :");
		int c=sc.nextInt();
		
		int largeno;
		
	if(a>b && a>c) {
		largeno=a;
		System.out.println("a is highest number");
	}
	else if(b>a && b>c) {
		largeno=a;

		System.out.println("b is highest number");
	}
	else {
		largeno=a;

	}
	System.out.println("c is highest number");

	sc.close();

	}

}
