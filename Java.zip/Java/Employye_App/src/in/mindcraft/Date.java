package in.mindcraft;

import java.util.Scanner;

class Date {
    private int day, month, year;

    public Date() {
        this.day = 1;
        this.month = 1;
        this.year = 2024;
    }

    public Date(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;
    }

    public void accept() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Day: ");
        this.day = scanner.nextInt();
        System.out.print("Enter Month: ");
        this.month = scanner.nextInt();
        System.out.print("Enter Year: ");
        this.year = scanner.nextInt();
    }

    public void display() {
        System.out.println(day + "-" + month + "-" + year);
    }
}
