package in.mindcraft;

class SalesPerson extends WageEmployee {
    int soldItems;
    int commissionPerItem;

    public SalesPerson(int empid, String name, String dob, int hours, int rate, int soldItems, int commissionPerItem) {
        super(empid, name, dob, hours, rate);
        this.soldItems = soldItems;
        this.commissionPerItem = commissionPerItem;
    }

    @Override
    public int calculateSalary() {
        return super.calculateSalary() + soldItems * commissionPerItem;
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Number of Items Sold: " + soldItems);
        System.out.println("Commission per Item: " + commissionPerItem);
    }
}
