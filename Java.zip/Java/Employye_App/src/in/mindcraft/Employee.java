package in.mindcraft;

class Employee {
    private int empid;
    private String name;
    private String dob;

    public Employee(int empid, String name, String dob) {
        this.empid = empid;
        this.name = name;
        this.dob = dob;
    }

    public void display() {
        System.out.println("Employee ID: " + empid);
        System.out.println("Employee Name: " + name);
        System.out.println("Employee Date of Birth: " + dob);
    }
}
