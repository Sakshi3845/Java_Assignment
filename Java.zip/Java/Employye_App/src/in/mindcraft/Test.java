package in.mindcraft;

public class Test {
    public static void main(String[] args) {
        WageEmployee w = new WageEmployee(101, "Sakshi Wagh", "01-Jan-2024", 9, 200);
        SalesPerson s = new SalesPerson(102, "Om Sharma", "15-Feb-2024", 8, 250, 50, 30);

        System.out.println("WageEmployee Details:");
        w.display();
        System.out.println("Employee Salary: " + w.calculateSalary());

        System.out.println("\nSalesPerson Details:");
        s.display();
        System.out.println("Salary: " + s.calculateSalary());
    }
}
