package set_interface;


import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Test {

	public static void main(String[] args) {
		Set<String> hashset=new HashSet<>();
		hashset.add("Sakshi");
		hashset.add("om");
		hashset.add("sakshi");
		hashset.add("ram");
		hashset.add("sakshi");
		System.out.println(hashset);
		
		Set<String> treeSet=new TreeSet<>();
		treeSet.add("Sakshi");
		treeSet.add("Anita");
		System.out.println(treeSet);
		
		for(String name:treeSet)
		{
			System.out.println(name);
			
		}
		
		
		

	}

}
