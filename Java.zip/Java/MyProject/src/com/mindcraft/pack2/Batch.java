package com.mindcraft.pack2;

public class Batch {
    private String courseName;
    private int batchStrength;

    public Batch(String courseName, int batchStrength) {
        this.courseName = courseName;
        this.batchStrength = batchStrength;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getBatchStrength() {
        return batchStrength;
    }

    public void setBatchStrength(int batchStrength) {
        this.batchStrength = batchStrength;
    }

    @Override
    public String toString() {
        return "Batch [Course Name=" + courseName + ", Batch Strength=" + batchStrength + "]";
    }
}

