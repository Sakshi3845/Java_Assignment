package default1;

import com.mindcraft.pack1.Student;
import com.mindcraft.pack2.Batch;

public class Main {
    public static void main(String[] args) {
        Student student = new Student(101, "John Doe");
        Batch batch = new Batch("Java Programming", 30);

        System.out.println(student);
        System.out.println(batch);
    }
}
