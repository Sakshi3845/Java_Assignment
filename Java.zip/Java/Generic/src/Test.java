
public class Test {

	public static int add(int ...a)
	{
		int sum=0;
		for(int i=0;i<a.length;i++) {
			sum=sum+a[i];
		}
		return sum;
	}
	public static void main(String[] args) {
		
		System.out.println(add(10,20));
		System.out.println(add(10,20,30,40));
		// TODO Auto-generated method stub

	}

}
