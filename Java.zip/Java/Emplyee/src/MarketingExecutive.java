
class MarketingExecutive extends Employee {
    private int kilometersTravelled;
    private double tourAllowance;
    private double telephoneAllowance;

    public MarketingExecutive(int empId, String name, double basicSalary, int kilometersTravelled) {
        super(empId, name, basicSalary);
        this.kilometersTravelled = kilometersTravelled;
        this.tourAllowance = 5 * kilometersTravelled; // Rs.5 per kilometer
        this.telephoneAllowance = 2000;
    }

    public double calculateGrossSalary() {
        return basicSalary + tourAllowance + telephoneAllowance;
    }

    public double calculateNetSalary() {
        double pf = 0.125 * basicSalary; // PF is 12.5% of basic salary
        return calculateGrossSalary() - pf;
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Kilometers Travelled: " + kilometersTravelled);
        System.out.println("Tour Allowance: " + tourAllowance);
        System.out.println("Telephone Allowance: " + telephoneAllowance);
        System.out.println("Gross Salary: " + calculateGrossSalary());
        System.out.println("Net Salary: " + calculateNetSalary());
    }
}
