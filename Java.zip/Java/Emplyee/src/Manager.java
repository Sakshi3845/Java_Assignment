
class Manager extends Employee {
    private double petrolAllowance;
    private double foodAllowance;
    private double otherAllowance;

    public Manager(int empId, String name, double basicSalary) {
        super(empId, name, basicSalary);
        this.petrolAllowance = 0.08 * basicSalary;
        this.foodAllowance = 0.12 * basicSalary;
        this.otherAllowance = 0.04 * basicSalary;
    }

    public double calculateGrossSalary() {
        return basicSalary + petrolAllowance + foodAllowance + otherAllowance;
    }

    public double calculateNetSalary() {
        double pf = 0.125 * basicSalary; // PF is 12.5% of basic salary
        return calculateGrossSalary() - pf;
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Petrol Allowance: " + petrolAllowance);
        System.out.println("Food Allowance: " + foodAllowance);
        System.out.println("Other Allowance: " + otherAllowance);
        System.out.println("Gross Salary: " + calculateGrossSalary());
        System.out.println("Net Salary: " + calculateNetSalary());
    }
}
