
public class Array {

	public static void main(String[] args) {
		
		int[][]a= {{1,2,3},{4,5,6},{7,8,9}};
		int [][]b= {{10,20,30,40},{60,50},{70,80,90}};
		int [][]c=new int[3][4];
		int [][]d=new int[3][];
		
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a[i].length;j++)
			{
				System.out.println(a[i][j]+" ");
			}
			System.out.println();
		}
		
		for(int [] temp:b)
		{
			for(int val:temp)
			{
				System.out.println(val+" ");
			}
			System.out.println();
		}
		// TODO Auto-generated method stub
		//1.Addition of two matrix 2.[3][3] matrix multiplication 3.1st code find min max number


	}

}
