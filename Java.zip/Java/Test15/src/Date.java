import java.util.Scanner;

class Date {
    private int dd, mm, yy;

    public Date() {
        this.dd = 1;
        this.mm = 1;
        this.yy = 2024;
    }

    public Date(int dd, int mm, int yy) {
        this.dd = dd;
        this.mm = mm;
        this.yy = yy;
    }

    public void accept() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Day: ");
        this.dd = sc.nextInt();
        System.out.print("Enter Month: ");
        this.mm = sc.nextInt();
        System.out.print("Enter Year: ");
        this.yy = sc.nextInt();
    }

    public void display() {
        System.out.println(dd + "-" + mm + "-" + yy);
    }
}