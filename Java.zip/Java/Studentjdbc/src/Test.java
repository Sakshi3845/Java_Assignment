import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Test {

    public static void main(String[] args) throws SQLException {
        Scanner sc = new Scanner(System.in);
        Connection c = DriverManager.getConnection("jdbc:mysql://localhost/student1", "root", "root");

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Insert record");
            System.out.println("2. Update record");
            System.out.println("3. Delete record");
            System.out.println("4. Display particular record from table");
            System.out.println("5. Display all records from table");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            PreparedStatement pstm;
            int rno;
            String name;
            long percentage;
            boolean s;

            switch (choice) {
                case 1:
                    System.out.println("Enter rollno, Name, Percentage:");
                    rno = sc.nextInt();
                    name = sc.next();
                    percentage = sc.nextLong();

                    pstm = c.prepareStatement("INSERT INTO student1 VALUES(?,?,?)");
                    pstm.setInt(1, rno);
                    pstm.setString(2, name);
                    pstm.setLong(3, percentage);
                    s = pstm.execute();
                    if (!s) {
                        System.out.println("Row inserted successfully!!");
                    }
                    break;

                case 2:
                    System.out.println("Enter rollno to update details:");
                    rno = sc.nextInt();
                    System.out.println("Enter updated name and percentage:");
                    name = sc.next();
                    percentage = sc.nextLong();

                    pstm = c.prepareStatement("UPDATE student1 SET sname = ?, percentage = ? WHERE rlno = ?");
                    pstm.setString(1, name);
                    pstm.setLong(2, percentage);
                    pstm.setInt(3, rno);

                    int rowsUpdated = pstm.executeUpdate();
                    if (rowsUpdated > 0) {
                        System.out.println("Row updated successfully!!");
                    }
                    break;

                case 3:
                    System.out.println("Enter the rollno to delete record:");
                    rno = sc.nextInt();

                    pstm = c.prepareStatement("DELETE FROM student1 WHERE rlno = ?");
                    pstm.setInt(1, rno);

                    int rowsDeleted = pstm.executeUpdate();
                    if (rowsDeleted > 0) {
                        System.out.println("Row deleted successfully!!");
                    }
                    break;

                case 4:
                    System.out.println("Enter rollno to display record:");
                    rno = sc.nextInt();

                    pstm = c.prepareStatement("SELECT * FROM student1 WHERE rlno = ?");
                    pstm.setInt(1, rno);

                    ResultSet rs = pstm.executeQuery();
                    if (rs.next()) {
                        System.out.println("Roll No: " + rs.getInt("rlno"));
                        System.out.println("Name: " + rs.getString("sname"));
                        System.out.println("Percentage: " + rs.getLong("percentage"));
                    } else {
                        System.out.println("Record not found.");
                    }
                    break;

                case 5:
                    pstm = c.prepareStatement("SELECT * FROM student1");
                    rs = pstm.executeQuery();

                    while (rs.next()) {
                        System.out.println("Roll No: " + rs.getInt("rlno") +
                                           ", Name: " + rs.getString("sname") +
                                           ", Percentage: " + rs.getLong("percentage"));
                    }
                    break;

                case 6:
                    c.close();
                    sc.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice, please try again.");
                    break;
            }
        }
    }
}
