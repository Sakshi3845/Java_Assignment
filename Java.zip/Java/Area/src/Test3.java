import java.util.Scanner;

public class Test3 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the No:");
		int num=sc.nextInt();
		
		if (num % 2 == 0) {
            System.out.println(num + " is even.");
        } else {
            System.out.println(num + " is odd.");
        }
		sc.close();
		// TODO Auto-generated method stub

	}
	


}
