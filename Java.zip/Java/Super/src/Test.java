import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Product {
    int id;
    String name;
    double price;

    public Product(int id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product [ID: " + id + ", Name: " + name + ", Price: " + price + "]";
    }
}

class Customer {
    private static int cnt = 1; 
    int id;
    String name;
    List<Product> cart = new ArrayList<>();
    double total;

    public Customer() {
        this.id = cnt++;
        this.name = "Customer" + id; 
    }

    public void addToCart(Product p) {
        cart.add(p);
        total += p.price; 
    }

    public void showCart() {
        System.out.println("Customer ID: " + id);
        System.out.println("Customer Name: " + name);
        System.out.println("Cart Items:");
        for (Product p : cart) {
            System.out.println(p);
        }
        System.out.println("Total Bill: " + total);
    }
}

public class Test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        List<Customer> customers = new ArrayList<>();
        
        List<Product> products = new ArrayList<>();
        products.add(new Product(1, "Product1", 100.0));
        products.add(new Product(2, "Product2", 200.0));
        products.add(new Product(3, "Product3", 300.0));

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Add Customer");
            System.out.println("2. Add Product to Customer Cart");
            System.out.println("3. Show Customer Cart");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            char choice = sc.next().charAt(0);

            switch (choice) {
                case '1':
                    Customer newCustomer = new Customer();
                    customers.add(newCustomer);
                    System.out.println("Customer " + newCustomer.name + " added.");
                    break;

                case '2':
                    System.out.print("Enter Customer ID: ");
                    int cid = sc.nextInt();
                    Customer selectedCustomer = null;
                    for (Customer c : customers) {
                        if (c.id == cid) {
                            selectedCustomer = c;
                            break;
                        }
                    }
                    if (selectedCustomer != null) {
                        System.out.println("Available Products:");
                        for (Product p : products) {
                            System.out.println(p);
                        }
                        System.out.print("Enter Product ID to add to cart: ");
                        int pid = sc.nextInt();
                        Product selectedProduct = null;
                        for (Product p : products) {
                            if (p.id == pid) {
                                selectedProduct = p;
                                break;
                            }
                        }
                        if (selectedProduct != null) {
                            selectedCustomer.addToCart(selectedProduct);
                            System.out.println("Product added to " + selectedCustomer.name + "'s cart.");
                        } else {
                            System.out.println("Product not found.");
                        }
                    } else {
                        System.out.println("Customer not found.");
                    }
                    break;

                case '3':
                    System.out.print("Enter Customer ID: ");
                    cid = sc.nextInt();
                    Customer foundCustomer = null;
                    for (Customer c : customers) {
                        if (c.id == cid) {
                            foundCustomer = c;
                            break;
                        }
                    }
                    if (foundCustomer != null) {
                        foundCustomer.showCart();
                    } else {
                        System.out.println("Customer not found.");
                    }
                    break;

                case '4':
                    System.out.println("Exiting...");
                    sc.close();
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
