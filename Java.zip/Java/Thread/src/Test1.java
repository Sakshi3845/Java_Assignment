class ThreadDemo implements Runnable{

	@Override
	public void run() {
		for(int i=0;i<5;i++)
		{
			System.out.println(Thread.currentThread().getName()+"Count:"+i);
			try {
				Thread.sleep(500);
			}
			catch(InterruptedException e) {
				System.out.println(e);
			}
		}
		
	}
	//2 thread 1at run 2nd mul add user should pass values
}

class thread extends ThreadDemo{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<5;i++)
		{
			System.out.println(Thread.currentThread().getName()+"Count:"+i);
			try {
				Thread.sleep(500);
			}
			catch(InterruptedException e) {
				System.out.println(e);
			}
		super.run();
	}
	
}
public class Test1 {

	public static void main(String[] args) {
		Thread t=new Thread(new ThreadDemo(),"Thread-1");
		Thread t1=new Thread(new ThreadDemo(),"Thread-2");
		Thread t2=new Thread(new ThreadDemo(),"Thread-3");
		
		t1.start();
		t.start();
		t2.start();

		
				

	}

}}
