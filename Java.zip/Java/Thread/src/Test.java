import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

class Person implements Comparable<Person>{
	 String name;
	 int age;
	
	 public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	

	@Override
	public int compareTo(Person o) {
		
		// TODO Auto-generated method stub
		return Integer.compare(this.age,o.age);
	}

	@Override
	public int hashCode() {
		return Objects.hash(age, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		return age == other.age && Objects.equals(name, other.name);
	}
	
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
	
}
public class Test {

	public static void main(String[] args) {
		List<Person> people=new ArrayList<Person>();
		
		
		people.add(new Person("Amisha",27));
		people.add(new Person("aryan",22));
		people.add(new Person("Sakshi",22));
		System.out.println(people);
		System.out.println(people.equals("om"));
		// TODO Auto-generated method stub
		//we have to check laptop cost with equal method and also check true or false

	}

}
