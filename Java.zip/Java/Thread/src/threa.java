import java.util.Scanner;

class Threaaa implements Runnable {
    int a;    

    public Threaaa(int a) {
        this.a = a;
    }

    @Override
    public void run() {
        for(int i = 0; i < 10; i++) {
            System.out.println("Addition: " + (a + i));
        }
    }
}

class Thread2 extends Threaaa {
    int a;

    public Thread2(int a, int a2) {
        super(a);
        this.a = a2;
    }

    @Override
    public void run() {
        for(int i = 0; i < 10; i++) {
            System.out.println("Multiplication: " + a + " * " + i + " = " + (a * i));
        }
        super.run(); // Call the addition loop after multiplication
    }
}

public class threa {

    public static void main(String[] args) {
        int a, b;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the value for addition: ");
        a = sc.nextInt();
        System.out.println("Enter value for multiplication: ");
        b = sc.nextInt();
        sc.close();

        Threaaa t1 = new Threaaa(a);
        Thread2 t2 = new Thread2(a, b);

        // Wrapping Runnable objects in Thread instances
        Thread thread1 = new Thread(t1);
        Thread thread2 = new Thread(t2);

        thread1.start();
        thread2.start();
    }
}
