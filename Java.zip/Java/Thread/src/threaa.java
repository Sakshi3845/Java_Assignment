import java.util.Scanner;

class threaaa implements Runnable{
	int a;	

	public threaaa(int a) {
		super();
		this.a = a;
	}


	@Override
	public void run() {
		for(int i=0;i<10;i++) {
			System.out.println("Addition : "+i);
		}
		// TODO Auto-generated method stub
		
	}
	
}

class thread2 extends threaaa{
	int a;

	public thread2(int a, int a2) {
		super(a);
		a = a2;
	}

	@Override
	public void run() {
		for(int i=0;i<10;i++)
		{
			System.out.println("Multiplication:"+a+"*"+i+":" +a*i);
		}
		super.run();
	}
	
}
public class threaa {

	public static void main(String[] args) {
		int a,b;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the values for addition : ");
		a=sc.nextInt();
		System.out.println("Enter values for multiplication : ");
		b=sc.nextInt();
		sc.close();
		
		threaaa t1=new threaaa(a);
		thread2 t2=new thread2(b);
       
        t1.start();
        t2.start();

		
	
		// TODO Auto-generated method stub

	}

}
