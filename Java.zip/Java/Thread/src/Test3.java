import java.awt.*;

@SuppressWarnings("serial")
class MovingCircle extends Frame implements Runnable {

    private int x1;
    private boolean movingRight;

    private Thread t1;

    public MovingCircle() {
        x1 = 100;
        movingRight = true;
        t1 = new Thread(this, "c1");
        t1.start();
    }

    @Override
    public void paint(Graphics g) {
        g.setColor(Color.darkGray);
        g.fillOval(x1, 100, 100, 100);
    }

    @Override
    public void run() {
        while (true) {
            synchronized (this) {
                if (movingRight) {
                    x1++;
                    if (x1 >= this.getWidth() - 100) {
                        movingRight = false;  // Change direction
                    }
                } else {
                    x1--;
                    if (x1 <= 0) {
                        movingRight = true;  // Change direction
                    }
                }
            }
            repaint();
            try {
                Thread.sleep(10);  // Slow down the movement for smoother animation
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        MovingCircle mc = new MovingCircle();
        mc.setSize(600, 600);
        mc.setVisible(true);
    }
}
