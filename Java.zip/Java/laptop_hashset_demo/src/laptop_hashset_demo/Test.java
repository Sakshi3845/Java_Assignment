package laptop_hashset_demo;

import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

class laptop{
private int lid;
private String make;
double cost;
public laptop(int lid,String make, double cost) {
	super();
	this.make = make;
	this.cost = cost;
}
@Override
public String toString() {
	return "laptop [lid=" + lid + ", make=" + make + ", cost=" + cost + "]";
}
@Override
public int hashCode() {
	return Objects.hash(cost, lid, make);
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	laptop other = (laptop) obj;
	return Double.doubleToLongBits(cost) == Double.doubleToLongBits(other.cost) && lid == other.lid
			&& Objects.equals(make, other.make);
}
public void show() {
	System.out.println(lid+" "+make+" "+cost+" ");
}
}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<laptop> l=new TreeSet<laptop>();
		laptop l1=(new laptop(1,"lg",10000));
		l.add(new laptop (2,"lenovo",3999));
		l.add(new laptop (3,"asus",45000));
		l.add(l1);
		System.out.println(l);
		System.out.println(l1);
		System.out.println();
		
		
		
		

	}

}
