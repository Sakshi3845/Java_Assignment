package in.mindcraft;

class WageEmployee extends Employee {
    int hours;
    int rate;

    public WageEmployee(int empid, String name, String dob, int hours, int rate) {
        super(empid, name, dob);
        this.hours = hours;
        this.rate = rate;
    }

    public int calculateSalary() {
        return hours * rate;
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Number of Hours Worked: " + hours);
        System.out.println("Rate per Hour: " + rate);
    }
}
