interface printable{
	public void printDetails();
	
}

class CktPlayer implements printable {
	private String name;
	private int runs;
	@Override
	public void printDetails() {
    	System.out.println("Name Of CktPlayer : "+name);
    	System.out.println("runs : "+runs);

		
		// TODO Auto-generated method stub
		
	}
	public CktPlayer(String name, int runs) {
		this.name = name;
		this.runs = runs;
	}
	
}

class FtPlayer implements printable {
	private String name;
	private int goals;
	@Override
	public void printDetails() {
    	System.out.println("Name of FtPlayer : "+name);
    	System.out.println("Goals : "+goals);

		// TODO Auto-generated method stub
		
	}
	public FtPlayer(String name, int goals) {
		this.name = name;
		this.goals = goals;
	}
	
}


public class Test {
    public static void main(String[] args) {
    	CktPlayer cp=new CktPlayer("Virat Kohli",100);
    	FtPlayer fp=new FtPlayer("Ronaldo",200);
    	
    	cp.printDetails();
    	fp.printDetails();
    	
    	
    }
	

}
