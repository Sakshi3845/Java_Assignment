import java.util.Scanner;

class Student {
    private static int rollCnt = 0;
    private int rlno;
    private String name;
    private Date dob;

    public Student() {
        this.rlno = ++rollCnt;
        this.name = " ";
        this.dob = new Date();
    }

    public Student(String name, Date dob) {
        this.rlno = ++rollCnt;
        this.name = name;
        this.dob = dob;
    }

    public void accept() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Student Name: ");
        this.name = sc.nextLine();

        System.out.println("Enter Date of Birth:");
        this.dob = new Date();
        this.dob.accept();
    }

    public void display() {
        System.out.println("Roll Number: " + rlno);
        System.out.println("Name: " + name);
        System.out.print("Date of Birth: ");
        dob.display();
    }

    public static void main(String[] args) {
        Student s = new Student();
        s.accept();
        s.display();

        Student s1= new Student();
        s1.accept();
        s1.display();
    }
}
