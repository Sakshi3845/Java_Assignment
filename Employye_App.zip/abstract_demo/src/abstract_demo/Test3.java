package abstract_demo;

class animal1{
	public void sound() {
		System.out.println("Sound");
	}
	
	class dog extends animal1{
		public void sound() {
			System.out.println("barks");
		}
	}
}
public class Test3 {

	public static void main(String[] args) {
		
		animal1 a=new animal1();
		a.sound();
		
		dog a2=new dog();
		a2.sound();
		// TODO Auto-generated method stub

	}

}
