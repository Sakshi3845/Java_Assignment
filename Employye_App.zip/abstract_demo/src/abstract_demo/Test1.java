package abstract_demo;

interface showable{
	void show();
	
	
}
interface printable {
	void print();
}

abstract class lib{
	abstract void store();
	abstract void store1();
}



class doc extends lib implements showable,printable{

	@Override
	public void show() {
		System.out.println("doc ...");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void print() {
		System.out.println("print doc");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void store() {
		System.out.println("store details");
		// TODO Auto-generated method stub
		
	}
	@Override
	 public void store1() {
		System.out.println("store More Info...");
		// TODO Auto-generated method stub
		
	}
	
	
}


public class Test1 {

	public static void main(String[] args) {
		doc d=new doc();
		d.show();
		d.print();
		d.store();
		d.store1();
		// TODO Auto-generated method stub

	}

}
