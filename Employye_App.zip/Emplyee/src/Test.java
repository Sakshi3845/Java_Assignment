
public class Test {

	public static void main(String[] args) {
		
		Manager m=new Manager(101,"Sakshi",20000);
		MarketingExecutive me=new MarketingExecutive(102,"Om",30000,100);
		
		System.out.println("Manager Details:");
        m.display();

        System.out.println("\nMarketing Executive Details:");
        me.display();

	}

}
