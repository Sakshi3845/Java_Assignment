package in.mindcraft.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="employeee")
public class Emp {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="eid")
	private int eid;
	private String empname;
	private String departname;
	
	
	public Emp() {
	}


	public Emp(int eid, String empname, String departname) {
		super();
		this.eid = eid;
		this.empname = empname;
		this.departname = departname;
	}


	@Override
	public String toString() {
		return "Emp [eid=" + eid + ", empname=" + empname + ", departname=" + departname + "]";
	}


	public int getEid() {
		return eid;
	}


	public void setEid(int eid) {
		this.eid = eid;
	}


	public String getEmpname() {
		return empname;
	}


	public void setEmpname(String empname) {
		this.empname = empname;
	}


	public String getDepartname() {
		return departname;
	}


	public void setDepartname(String departname) {
		this.departname = departname;
	}
	

}
