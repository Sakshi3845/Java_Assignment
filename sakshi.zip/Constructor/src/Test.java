import java.util.Scanner;

class AccountHolder{
	private int ac_no;
	private String ac_name;
	private double balance;
	
	public AccountHolder(int ac_no, String ac_name, double balance) {
		this.ac_no = ac_no;
		this.ac_name = ac_name;
		this.balance = balance;
	}
	public int getAc_no() {
		return ac_no;
	}
	public void setAc_no(int ac_no) {
		this.ac_no = ac_no;
	}
	public String getAc_name() {
		return ac_name;
	}
	public void setAc_name(String ac_name) {
		this.ac_name = ac_name;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public void deposit(double amount) {
		balance=amount+balance;
	}
	
	public void withdraw(double amount) {
		balance=balance=amount;
	}
	public void details() {
		System.out.println(ac_no+"\t"+ac_name+"\t"+balance);
	}
	
	
}
public class Test {

	Test(){
		
	};
	public static void main(String[] args) {
		
		int cnt=0,choice,acno;
		AccountHolder acc[] =new AccountHolder[10];
		Scanner sc=new Scanner(System.in);
		while(true) {
			System.out.println("1.Add Account Details:");
			System.out.println("2.Display Account details :");
			System.out.println("3.Deposit Accounr");
			System.out.println("4.Withdra amount");
			System.out.println("5.Exit");
			
			System.out.println("Enter the choice:");
			choice=sc.nextInt();
			
			switch(choice) {
			case 1:
				System.out.println("Enter Account no,Enter Account holderName,Enter Balance:");
				acc[cnt++]=new AccountHolder(sc.nextInt(),sc.next(),sc.nextDouble());
				break;
				
			case 2:
				System.out.println("All Account Details");
				for (int i=0;i<cnt;i++) {
					acc[i].details();
				}
				break;
				
			case 3:
				System.out.println("Enter Account number for deposit");
				acno=sc.nextInt();
				for (int i=0;i<cnt;i++)
					if(acno==acc[i].getAc_no()) {
						
						boolean flag;
						if(flag=true) {
							System.out.println("Amount Deposit");
							acc[i].deposit(sc.nextDouble());
						}
						System.out.println("Amount id Deposited!!!");
					}
					
			
				break;
				
			case 4:
				System.out.println("enter the acno for withdraw");
				acno=sc.nextInt();
				for(int i=0;i<cnt;i++) {
					System.out.println("Amount Withdraw");
					double wamt = sc.nextDouble();
					if(wamt>acc[i].getBalance()) {
						System.out.println("Insufficient Balance!!!");
					}
					else {
						System.out.println("Amount withdraw succesfully!!!\n");
					}
					acc[i].withdraw(sc.nextDouble());
				}
				break;
				
				case 5:
					System.exit(0);
			
		}
		// TODO Auto-generated method stub

	}

	}}
