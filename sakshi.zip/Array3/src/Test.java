import java.util.Scanner;

public class Test {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of elements in the array: ");
        int size = sc.nextInt();

        int[] matrix = new int[size];  
        int[] mul = new int[size];  

        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < size; i++) {
            matrix[i] = sc.nextInt();
        }

        for (int i = 0; i < size; i++) {
            mul[i] = matrix[i] * 5;
        }

        System.out.println("Multiplied array:");
        for (int i = 0; i < size; i++) {
            System.out.print(mul[i] + " ");
        }

        sc.close();
    }
}
