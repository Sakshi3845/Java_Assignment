		class Array
		{
		public void fmax() {
		int a[]= {5,23,4,15,6};
        int max=a[0];
        for(int i=0;i<a.length;i++)
        {
        	if(a[i]>max) {
        		
				max=a[i];
        	}
        }
        System.out.println("max is : "+max);
	 }
		public void fmin() {
			int []a={5,23,4,15,6};
			int min=a[0];
			for(int i=0;i<a.length;i++)
			{
				if (a[i]<min) {
					min=a[i];
				}
			}
			System.out.println("min is : "+min);
		}

       }
		public class Test {
			public static void main(String[] args) {
				
				Array n1=new Array();
				n1.fmax();
				n1.fmin();

			
			}
		}

	
